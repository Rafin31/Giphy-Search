import React from 'react';
import './App.css';

function App() {
  return (
    <div className="app">
      <header className="app-header">
        <div className="hero">
          Giphy Search
        </div>
      </header>
    </div>
  );
}

export default App;
